#include "ORB/global_defination/global_defination.h"
#include "ORB/ORBFeature.hpp"
#include <chrono>
#include <iostream>

using namespace ORB;
using namespace std;

int main(int argc, char** argv)
{
    google::InitGoogleLogging(argv[0]);  //glog初始化
    FLAGS_alsologtostderr = true;  //glog设置记录Log到本地及终端显示

    std::string config_path = WORK_SPACE_PATH + "/config/camera_para.yaml";
    std::string image_path = WORK_SPACE_PATH + "/image/distorted.png";

    std::shared_ptr<ORBFeature> orb_feature_ptr = std::make_shared<ORBFeature>(image_path, config_path);

    std::vector<cv::KeyPoint> vKeypoints;
    cv::Mat descriptor;
    // cv::OutputArray descriptor;
    
    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();

    orb_feature_ptr->ExtractORB(vKeypoints, descriptor);

    cv::Mat image = cv::imread(image_path, cv::IMREAD_GRAYSCALE);
    LOG(INFO) << "vKeypoints size " << vKeypoints.size();
    LOG(INFO) << "descriptor size " << descriptor.rows;

    cv::Mat outImage;
    cv::drawKeypoints(image, vKeypoints, outImage, cv::Scalar::all(-1), cv::DrawMatchesFlags::DEFAULT);
    cv::imshow("ORB features by orb2", outImage);

    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_used = chrono::duration_cast<chrono::duration<double>>(t2-t1);
    cout << "orb2 extract orb cost = " << time_used.count() << "s" << endl;
    t1 = chrono::steady_clock::now();

    orb_feature_ptr->ExtractORB();

    t2 = chrono::steady_clock::now();
    time_used = chrono::duration_cast<chrono::duration<double>>(t2-t1);
    cout << "opencv extract orb cost = " << time_used.count() << "s" << endl;

    cv::waitKey();
    return 0;
}


