#include "ORB/ORBFeature.hpp"

// #define max(a,b) (((a) > (b)) ? (a) : (b))
// #define min(a,b) (((a) < (b)) ? (a) : (b))


using namespace std;

int N = 0; //numbers of keypoint
cv::Mat tmp;
cv::Mat d1,d2;
const int TH_HIGH = 100;
const int TH_LOW = 50;
const int HISTO_LENGTH = 30;


namespace ORB {
    
    const int HISTO_LENGTH = 30;

    ORBFeature::ORBFeature(const std::string& image_one_path, const std::string& image_two_path, const std::string& config_path)
    {
        camera_ptr = std::make_shared<Parameter>(config_path);
        image_one = cv::imread(image_one_path, cv::IMREAD_GRAYSCALE);
        image_two = cv::imread(image_two_path, cv::IMREAD_GRAYSCALE);

        tmp = image_one;

        orb_extractor_ptr = std::make_shared<ORBextractor>(camera_ptr->nFeatures, camera_ptr->scalseFactor, camera_ptr->nLevels, camera_ptr->iniThFAST, camera_ptr->minThFAST);
    }

    void ORBFeature::Run()
    {  
        std::vector<cv::KeyPoint> keypoints_1, keypoints_2;
        std::vector<cv::DMatch> matches, des_good_matches, good_matches;
        FindFeatureMatches(image_one, image_two, keypoints_1, keypoints_2, matches, des_good_matches);

        N = keypoints_1.size();
        
        cv::Ptr<cv::DescriptorExtractor> descriptorss = cv::ORB::create();
        descriptorss->compute(image_one, keypoints_1, d1);
        descriptorss->compute(image_two, keypoints_2, d2);
        

        cv::Mat img;
        cv::drawMatches(image_one, keypoints_1, image_two, keypoints_2, matches, img);
        cv::imshow("all matches", img); //暴力匹配
        cv::imwrite("all_match.jpg",img);
        // cv::waitKey(0);

        /************************你需要完成的函数*************************************/
        UseHistConsistency(keypoints_1, keypoints_2, matches, good_matches); //直方图滤除点
        cv::Mat good_img;
        cv::drawMatches(image_one, keypoints_1, image_two, keypoints_2, good_matches, good_img);
        cv::imshow("hist_match", good_img);
        cv::imwrite("hist_match.jpg",good_img);
        // cv::waitKey(0);

        cv::Mat des_img;
        cv::drawMatches(image_one, keypoints_1, image_two, keypoints_2, des_good_matches, des_img); //描述子匹配
        cv::imshow("des_match", des_img);
        cv::imwrite("des_match.jpg",des_img);
        cv::waitKey(0);

    }

    /**
     *  matches: 中存放的是暴力匹配的数据
     *  good_matches: 该数据中，你需要使用直方图滤除不一致的匹配点对，将匹配好的数据放入该容器中
     */
    void ORBFeature::UseHistConsistency(const std::vector<cv::KeyPoint>& keypoints_1,
                                        const std::vector<cv::KeyPoint>& keypoints_2, 
                                        const std::vector<cv::DMatch>& matches, 
                                        std::vector<cv::DMatch>& good_matches)
    {
        /**
         *  请您使用直方图滤除不一致的匹配点对。
         */
        int nmatches = 0;
        std::vector<int> vnMatches12 = vector<int>(keypoints_1.size(),-1);
        
        std::vector<int> rotHist[HISTO_LENGTH];//构建旋转直方图
        for(int i = 0;i<HISTO_LENGTH;i++)
            rotHist[i].reserve(500); //  预分配空间
        const float factor = HISTO_LENGTH/360.0f;
        std::vector<int> vMatchedDistance(keypoints_2.size(),INT_MAX);//匹配点对距离，按照F2特征点数目分配空间
        std::vector<int> vnMatches21(keypoints_2.size(),-1);//从帧2到帧1的反向匹配，按照F2特征点数目分配空间
        //遍历帧1中的所有特征点
        for(size_t i1=0, iend1=keypoints_1.size(); i1 < iend1; i1++)
        {
            cv::KeyPoint kp1 = keypoints_1[i1];
            int level1 = kp1.octave;// ?
            //只使用原始图像上提取的特征点
            if (level1 > 0) continue;

            int bestDist = INT_MAX;     //最佳描述子匹配距离，越小越好
            int bestDist2 = INT_MAX;    //次佳描述子匹配距离
            int bestIdx2 = -1;          //最佳候选特征点在F2中的index

            int dist = DescriptorDistance(d1,d2);
            
            if(dist < bestDist)
            {
                bestDist2 = bestDist;
                bestDist = dist;
                // bestIdx2 = i2;
            }
            else if (dist < bestDist2)
            {
                bestDist2 = dist;
            }

            if(bestDist<=TH_LOW)
            {
                // 最佳距离比次佳距离要小于设定的比例，这样特征点辨识度更高
                if(bestDist<(float)bestDist2 * 0.6)
                {
                    // 如果找到的候选特征点对应F1中特征点已经匹配过了，说明发生了重复匹配，将原来的匹配也删掉
                    if(vnMatches21[bestIdx2]>=0)
                    {
                        vnMatches12[vnMatches21[bestIdx2]]=-1;
                        nmatches--;
                    }
                    // 次优的匹配关系，双向建立
                    // vnMatches12保存参考帧F1和F2匹配关系，index保存是F1对应特征点索引，值保存的是匹配好的F2特征点索引
                    vnMatches12[i1]=bestIdx2;
                    vnMatches21[bestIdx2]=i1;
                    vMatchedDistance[bestIdx2]=bestDist;
                    nmatches++;

                    // Step 5 计算匹配点旋转角度差所在的直方图
                    if(1)
                    {
                        // 计算匹配特征点的角度差，这里单位是角度°，不是弧度
                        float rot = keypoints_1[i1].angle-keypoints_2[bestIdx2].angle;
                        if(rot<0.0)
                            rot+=360.0f;
                        // 前面factor = HISTO_LENGTH/360.0f 
                        // bin = rot / 360.of * HISTO_LENGTH 表示当前rot被分配在第几个直方图bin  
                        int bin = round(rot*factor);
                        // 如果bin 满了又是一个轮回
                        if(bin==HISTO_LENGTH)
                            bin=0;
                        assert(bin>=0 && bin<HISTO_LENGTH);
                        rotHist[bin].push_back(i1);
                    }
                }
            }  
        }
        // Step 6 ：根据直方图统计信息剔除错误匹配的特征点对
        if(1)
        {
            int ind1=-1;
            int ind2=-1;
            int ind3=-1;
            // 筛选出在旋转角度差落在在直方图区间内数量最多的前三个bin的索引
            ComputeThreeMaxima(rotHist,HISTO_LENGTH,ind1,ind2,ind3);

            for(int i=0; i<HISTO_LENGTH; i++)
            {
                if(i==ind1 || i==ind2 || i==ind3)
                    continue;
                // 剔除掉不在前三的匹配对，因为他们不符合“主流旋转方向”    
                for(size_t j=0, jend=rotHist[i].size(); j<jend; j++)
                {
                    int idx1 = rotHist[i][j];
                    if(vnMatches12[idx1]>=0)
                    {
                        vnMatches12[idx1]=-1;
                        nmatches--;
                    }
                }
            }
        }
        //Update prev matched
        // Step 7 将最后通过筛选的匹配好的特征点保存到goodmatches
        for(size_t i1=0, iend1=vnMatches12.size(); i1<iend1; i1++)
            if(vnMatches12[i1] >= 0){
                good_matches[i1].queryIdx = keypoints_2[vnMatches12[i1]].pt.x;
                good_matches[i1].trainIdx = keypoints_2[vnMatches12[i1]].pt.y;
            }

        // return nmatches;


    }

    /**
     * @brief 筛选出在旋转角度差落在在直方图区间内数量最多的前三个bin的索引
     * 
     * @param[in] histo         匹配特征点对旋转方向差直方图
     * @param[in] L             直方图尺寸
     * @param[in & out] ind1          bin值第一大对应的索引
     * @param[in & out] ind2          bin值第二大对应的索引
     * @param[in & out] ind3          bin值第三大对应的索引
     */
    void ORBFeature::ComputeThreeMaxima(std::vector<int>* histo, const int L, int &ind1, int &ind2, int &ind3)
    {
        int max1=0;
        int max2=0;
        int max3=0;

        for(int i=0; i<L; i++)
        {
            const int s = histo[i].size();
            if(s>max1)
            {
                max3=max2;
                max2=max1;
                max1=s;
                ind3=ind2;
                ind2=ind1;
                ind1=i;
            }
            else if(s>max2)
            {
                max3=max2;
                max2=s;
                ind3=ind2;
                ind2=i;
            }
            else if(s>max3)
            {
                max3=s;
                ind3=i;
            }
        }

        // 如果差距太大了,说明次优的非常不好,这里就索性放弃了,都置为-1
        if(max2<0.1f*(float)max1)
        {
            ind2=-1;
            ind3=-1;
        }
        else if(max3<0.1f*(float)max1)
        {
            ind3=-1;
        }
    }

    void ORBFeature::ComputeOneMaxima(std::vector<int>* histo, const int L, int &index)
    {
        int max1=0;

        for(int i=0; i<L; i++)
        {
            const int s = histo[i].size();
            if(s>max1)
            {
                max1=s;
                index=i;
            }
        }
    }

    void ORBFeature::MatchImage() //官方测试用函数
    {
        std::vector<cv::KeyPoint> keypoints_1, keypoints_2;
        cv::Mat descriptors_1, descriptors_2;
        std::vector<cv::DMatch> matches, good_matches;

        FindFeatureMatches(image_one, image_two, keypoints_1, keypoints_2, matches, good_matches);

        cv::Mat img;
        cv::drawMatches(image_one, keypoints_1, image_two, keypoints_2, matches, img);
        cv::imshow("all matches", img); //暴力匹配
        cv::waitKey();

        cv::Mat img_goodmatch;
        cv::drawMatches(image_one, keypoints_1, image_two, keypoints_2, good_matches, img_goodmatch);
        cv::imshow("good matches", img_goodmatch);
        cv::waitKey(0);
    }

    /**
     *  vPoint_one ： 图像1上的匹配特征点
     *  vPoint_two :  图像2上的匹配特征点
     */
    void ORBFeature::PoseEstimation(cv::Mat& R21, cv::Mat& t21, std::vector<cv::Point2f>& vPoint_one, std::vector<cv::Point2f>& vPoint_two)
    {
        std::vector<cv::KeyPoint> keypoints_1, keypoints_2;
        cv::Mat descriptors_1, descriptors_2;
        std::vector<cv::DMatch> matches, good_matches;
        FindFeatureMatches(image_one, image_two, keypoints_1, keypoints_2, matches, good_matches);

        for (int i = 0, id = good_matches.size(); i < id; i++)
        {
            vPoint_one.push_back(keypoints_1[good_matches[i].queryIdx].pt);
            vPoint_two.push_back(keypoints_2[good_matches[i].trainIdx].pt);
        }        

        cv::Point2d principal_point(camera_ptr->cx, camera_ptr->cy);
        double focal_length = camera_ptr->fx;
        cv::Mat essential_matrix = cv::findEssentialMat(vPoint_one, vPoint_two, focal_length, principal_point);

        cv::recoverPose(essential_matrix, vPoint_one, vPoint_two, R21, t21, focal_length, principal_point);
    }

    /**
     *  points 是三维点的坐标
     */ 
    void ORBFeature::Triangulation(std::vector<cv::Point3d>& points)
    {
        cv::Mat R21, t21;
        std::vector<cv::Point2f> vPoint_one, vPoint_two;
        std::vector<cv::Point2f> vPoint_one_temp, vPoint_two_temp;
        PoseEstimation(R21, t21, vPoint_one, vPoint_two);
        vPoint_one_temp = vPoint_one;
        vPoint_two_temp = vPoint_two;

        for (int i = 0, id = vPoint_one.size(); i < id; i++)
        {
            float x1 = (vPoint_one[i].x - camera_ptr->cx)/camera_ptr->fx; 
            float y1 = (vPoint_one[i].y - camera_ptr->cy)/camera_ptr->fy;

            float x2 = (vPoint_two[i].x - camera_ptr->cx)/camera_ptr->fx;
            float y2 = (vPoint_two[i].y - camera_ptr->cy)/camera_ptr->fy;

            vPoint_one[i] = cv::Point2f(x1, y1);
            vPoint_two[i] = cv::Point2f(x2, y2);
        }
        cv::Mat P1 = (cv::Mat_<float>(3, 4) <<
                        1, 0, 0, 0,
                        0, 1, 0, 0,
                        0, 0, 1, 0);
        cv::Mat P2(3, 4, CV_32F);
        R21.copyTo(P2.rowRange(0, 3).colRange(0, 3));
        t21.copyTo(P2.rowRange(0, 3).col(3));
        cv::Mat pts_4d;
        points.clear();
        cv::triangulatePoints(P1, P2, vPoint_one, vPoint_two, pts_4d);
        for (int i = 0; i < pts_4d.cols; i++)
        {
            cv::Mat x = pts_4d.col(i);
            x /= x.at<float>(3, 0);
            cv::Point3d p(x.at<float>(0, 0), x.at<float>(1, 0), x.at<float>(2, 0));
            points.push_back(p);
        }
    }

    void ORBFeature::FindFeatureMatches(const cv::Mat& src_image_one, const cv::Mat& src_image_two,
                                        std::vector<cv::KeyPoint>& vkeypoints_one, 
                                        std::vector<cv::KeyPoint>& vkeypoints_two,
                                        std::vector<cv::DMatch>& matches, std::vector<cv::DMatch>& good_matches)
    {
        cv::Mat descriptors_one, descriptors_two;
        if (1)
        {   
            ExtractORB(src_image_one, vkeypoints_one, descriptors_one);
            ExtractORB(src_image_two, vkeypoints_two, descriptors_two);
        }
        else {
            ORBSLAM2ExtractORB(src_image_one, vkeypoints_one, descriptors_one);
            ORBSLAM2ExtractORB(src_image_two, vkeypoints_two, descriptors_two);
        }

        cv::Ptr<cv::DescriptorMatcher> matcher = cv::DescriptorMatcher::create("BruteForce-Hamming");
        matcher->match(descriptors_one, descriptors_two, matches);
        double min_dist = 10000, max_dist = 0;
        for (int i = 0; i < descriptors_one.rows; i++)
        {
            double dist = matches[i].distance;
            if (dist < min_dist) min_dist = dist;
            if (dist > max_dist) max_dist = dist;
        }

        static bool showFlag = false;
        if(showFlag == false)
        {
            showFlag = true;
            LOG(INFO) << "-- Max dist : " << max_dist;
            LOG(INFO) << "-- Min dist : " << min_dist;
        }

        for (int i = 0; i < descriptors_one.rows; i++)
        {
            if (matches[i].distance <= std::max(2 * min_dist, 30.0))
            {
                good_matches.push_back(matches[i]);
            }
        }    

    }

    cv::Scalar ORBFeature::get_color(float depth)
    {
        float up_th = 50, low_th = 10, th_range = up_th - low_th;
        if (depth > up_th) depth = up_th;
        if (depth < low_th) depth = low_th;
        return cv::Scalar(255 * depth / th_range, 0, 255 * (1 - depth / th_range));
    }

    void ORBFeature::ExtractORB(const cv::Mat& image, std::vector<cv::KeyPoint>& vkeypoints, cv::Mat& descriptors)
    {
        cv::Ptr<cv::FeatureDetector> detector = cv::ORB::create();
        cv::Ptr<cv::DescriptorExtractor> descriptor = cv::ORB::create();

        detector->detect(image, vkeypoints);
        descriptor->compute(image, vkeypoints, descriptors);
    }

    void ORBFeature::UndistortImage(const cv::Mat& image, cv::Mat& outImage)
    {
        int rows = image.rows;
        int cols = image.cols;
        cv::Mat Image = cv::Mat(rows, cols, CV_8UC1);

        for (int v = 0; v < rows; v++)
        {
            for (int u = 0; u < cols; u++)
            {
                double x = (u - camera_ptr->cx)/camera_ptr->fx;
                double y = (v - camera_ptr->cy)/camera_ptr->fy;

                double r = sqrt(x * x + y * y);
                double r2 = r * r;
                double r4 = r2 * r2;

                double x_dis = x * (1 + camera_ptr->k1 * r2 + camera_ptr->k2 * r4) + 2 * camera_ptr->p1 * x * y + camera_ptr->p2 * (r2 + 2 * x * x);
                double y_dis = y * (1 + camera_ptr->k1 * r2 + camera_ptr->k2 * r4) + camera_ptr->p1 * (r2 + 2 * y * y) + 2 * camera_ptr->p2 * x * y;

                double u_dis = camera_ptr->fx * x_dis + camera_ptr->cx;
                double v_dis = camera_ptr->fy * y_dis + camera_ptr->cy;

                if (u_dis >= 0 && v_dis >= 0 && u_dis < cols && v_dis < rows)
                {
                    Image.at<uchar>(v, u) = image.at<uchar>((int)v_dis, (int)u_dis);
                }
                else {
                    Image.at<uchar>(v, u) = 0;
                }
            }
            outImage = Image;
        }
    }

    void ORBFeature::ORBSLAM2ExtractORB(const cv::Mat& srcImage, std::vector<cv::KeyPoint>& vkeypoints, cv::Mat& descriptors)
    {
        orb_extractor_ptr->operator()(srcImage, cv::Mat(), vkeypoints, descriptors);       
    }

    int ORBFeature::DescriptorDistance(const cv::Mat &a, const cv::Mat &b)
    {
        const int *pa = a.ptr<int32_t>();
        const int *pb = b.ptr<int32_t>();

        int dist=0;

        // 8*32=256bit

        for(int i=0; i<8; i++, pa++, pb++)
        {
            unsigned  int v = *pa ^ *pb;        // 相等为0,不等为1
            // 下面的操作就是计算其中bit为1的个数了,这个操作看上面的链接就好
            // 其实我觉得也还阔以直接使用8bit的查找表,然后做32次寻址操作就完成了;不过缺点是没有利用好CPU的字长
            v = v - ((v >> 1) & 0x55555555);
            v = (v & 0x33333333) + ((v >> 2) & 0x33333333);
            dist += (((v + (v >> 4)) & 0xF0F0F0F) * 0x1010101) >> 24;
        }

        return dist;
    }
}

// float mnMinX = 0.0f, mnMaxX = 0.0f, mnMinY = 0.0f, mnMaxY = 0.0f, mfGridElementWidthInv=0.0f,mfGridElementHeightInv=0.0f; //自己加的
// int FRAME_GRID_COLS = 64;
// int FRAME_GRID_ROWS = 48;


// /**
//  * @brief 找到在 以x,y为中心,半径为r的圆形内且金字塔层级在[minLevel, maxLevel]的特征点
//  * 
//  * @param[in] x                     特征点坐标x
//  * @param[in] y                     特征点坐标y
//  * @param[in] r                     搜索半径 
//  * @param[in] minLevel              最小金字塔层级
//  * @param[in] maxLevel              最大金字塔层级
//  * @return vector<size_t>           返回搜索到的候选匹配点id
//  */
// vector<size_t> GetFeaturesInArea(const float &x, const float  &y, const float  &r, const int minLevel, const int maxLevel) 
// {
// 	// 存储搜索结果的vector
//     vector<size_t> vIndices;
//     vIndices.reserve(N);

//     ComputeImageBounds(tmp);

//     // Step 1 计算半径为r圆左右上下边界所在的网格列和行的id
//     // 查找半径为r的圆左侧边界所在网格列坐标。这个地方有点绕，慢慢理解下：
//     // (mnMaxX-mnMinX)/FRAME_GRID_COLS：表示列方向每个网格可以平均分得几个像素（肯定大于1）
//     // mfGridElementWidthInv=FRAME_GRID_COLS/(mnMaxX-mnMinX) 是上面倒数，表示每个像素可以均分几个网格列（肯定小于1）
// 	// (x-mnMinX-r)，可以看做是从图像的左边界mnMinX到半径r的圆的左边界区域占的像素列数
// 	// 两者相乘，就是求出那个半径为r的圆的左侧边界在哪个网格列中
//     // 保证nMinCellX 结果大于等于0
//     const int nMinCellX = max(0,(int)floor( (x-mnMinX-r)*mfGridElementWidthInv));


// 	// 如果最终求得的圆的左边界所在的网格列超过了设定了上限，那么就说明计算出错，找不到符合要求的特征点，返回空vector
//     if(nMinCellX>=FRAME_GRID_COLS)
//         return vIndices;

// 	// 计算圆所在的右边界网格列索引
//     const int nMaxCellX = min((int)FRAME_GRID_COLS-1, (int)ceil((x-mnMinX+r)*mfGridElementWidthInv));
// 	// 如果计算出的圆右边界所在的网格不合法，说明该特征点不好，直接返回空vector
//     if(nMaxCellX<0)
//         return vIndices;

// 	//后面的操作也都是类似的，计算出这个圆上下边界所在的网格行的id
//     const int nMinCellY = max(0,(int)floor((y-mnMinY-r)*mfGridElementHeightInv));
//     if(nMinCellY>=FRAME_GRID_ROWS)
//         return vIndices;

//     const int nMaxCellY = min((int)FRAME_GRID_ROWS-1,(int)ceil((y-mnMinY+r)*mfGridElementHeightInv));
//     if(nMaxCellY<0)
//         return vIndices;

//     // 检查需要搜索的图像金字塔层数范围是否符合要求
//     //? 疑似bug。(minLevel>0) 后面条件 (maxLevel>=0)肯定成立
//     //? 改为 const bool bCheckLevels = (minLevel>=0) || (maxLevel>=0);
//     const bool bCheckLevels = (minLevel>0) || (maxLevel>=0);

//     // Step 2 遍历圆形区域内的所有网格，寻找满足条件的候选特征点，并将其index放到输出里
//     for(int ix = nMinCellX; ix<=nMaxCellX; ix++)
//     {
//         for(int iy = nMinCellY; iy<=nMaxCellY; iy++)
//         {
//             // 获取这个网格内的所有特征点在 Frame::mvKeysUn 中的索引
//             const vector<size_t> vCell = mGrid[ix][iy];
// 			// 如果这个网格中没有特征点，那么跳过这个网格继续下一个
//             if(vCell.empty())
//                 continue;

//             // 如果这个网格中有特征点，那么遍历这个图像网格中所有的特征点
//             for(size_t j=0, jend=vCell.size(); j<jend; j++)
//             {
// 				// 根据索引先读取这个特征点 
//                 const cv::KeyPoint &kpUn = mvKeysUn[vCell[j]];
// 				// 保证给定的搜索金字塔层级范围合法
//                 if(bCheckLevels)
//                 {
// 					// cv::KeyPoint::octave中表示的是从金字塔的哪一层提取的数据
// 					// 保证特征点是在金字塔层级minLevel和maxLevel之间，不是的话跳过
//                     if(kpUn.octave<minLevel)
//                         continue;
//                     if(maxLevel>=0)		//? 为何特意又强调？感觉多此一举
//                         if(kpUn.octave>maxLevel)
//                             continue;
//                 }               

//                 // 通过检查，计算候选特征点到圆中心的距离，查看是否是在这个圆形区域之内
//                 const float distx = kpUn.pt.x-x;
//                 const float disty = kpUn.pt.y-y;

// 				// 如果x方向和y方向的距离都在指定的半径之内，存储其index为候选特征点
//                 // if(fabs(distx)<r && fabs(disty)<r) //源代码这样写，搜索区域为正方形
//                 if(distx*distx + disty*disty < r*r) // 这里改成圆形搜索区域，更合理
//                     vIndices.push_back(vCell[j]);
//             }
//         }
//     }
//     return vIndices;
// }

// void ComputeImageBounds(const cv::Mat &imLeft)	
// {
//     // 如果畸变参数不为0，用OpenCV函数进行畸变矫正
    
//     // 如果畸变参数为0，就直接获得图像边界
//     mnMinX = 0.0f;
//     mnMaxX = imLeft.cols;
//     mnMinY = 0.0f;
//     mnMaxY = imLeft.rows;
    
// }